CREATE VIEW dbo.material_join_storage
AS
SELECT DISTINCT 
                d.ID, a.MaterialCode, a.MaterialName, a.PipeCode, a.CASNO, b.PackageType, b.PackageWeight, b.Price, 
                b.SupplierName, b.Manufacturer, b.Tel, b.Mail, c.BatchNum, c.InputWeight, c.FirstInputWeight, c.Unit, c.InputDate, 
                c.ProductDate, c.State, c.ExpiredDate, c.ValidDays, c.BuyBatch, d.Iquantity, d.Location, c.Department
FROM      dbo.Material AS a INNER JOIN
                dbo.MaterialInfo AS b ON a.MaterialCode = b.MaterialCode INNER JOIN
                dbo.MaterialStorage AS c ON b.ID = c.InfoId INNER JOIN
                dbo.MaterialStorageSub AS d ON c.BatchNum = d.BatchNum
go

