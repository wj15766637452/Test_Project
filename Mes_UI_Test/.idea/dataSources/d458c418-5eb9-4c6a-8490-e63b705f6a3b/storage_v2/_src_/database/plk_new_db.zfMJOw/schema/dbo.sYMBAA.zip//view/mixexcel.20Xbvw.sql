			CREATE view mixExcel as
								select distinct c.Wocode,a.Batch,b.Iquantity,b.TechCode,d.Version,c.FomulaCode,a.DeviceCode,e.Actual_nw,
								e.FeedDateTime as startdatetime,a.CreateDateTime as enddatetime,
								DATEDIFF(MINUTE, e.FeedDateTime, a.CreateDateTime) AS ContinuedMinute ,
								a.NowStep,f.TechData,a.MixLogData
								from mixlog a
								join Batch b on a.Batch = b.Batch
								join wocode c on b.Wocode = c.Wocode
								join Tech d on b.TechCode = d.TechCode
								join BurdenProcess e on a.Batch = e.batch
								join TechVersion f on d.TechCode = f.TechCode
      go

