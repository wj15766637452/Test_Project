-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER sheet_burdendatetime_batch
   ON  dbo.BurdenSheet
   AFTER update
AS 
if UPDATE(burdendatetime)
BEGIN
		

	declare @datetime datetime
	declare @batch nvarchar(50)
	select @datetime = burdendatetime,@batch = Batch from inserted
	update Batch set StartDateTime = @datetime where Batch = @batch

END
go

