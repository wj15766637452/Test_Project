-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[分包记录]
   ON  dbo.MaterialStorageSub
   AFTER INSERT,UPDATE
AS 
BEGIN
	declare @parenid int
	declare @absoluteWeight int
	declare @updatestate int
	declare @updateweight real
	declare @updatedatetime datetime
	declare @updateusername nvarchar(50)
	declare @packageWeight real
	declare @infoid int
	declare @batchnum nvarchar(50)
	select @batchnum=batchnum,@parenid=ID,@updatestate=State,@updateweight=Iquantity,@updatedatetime=updatedatetime,@updateusername=updateusername from inserted
	select @infoid=InfoId from MaterialStorage where batchnum = @batchnum
	select @packageWeight=PackageWeight from MaterialInfo where id = @infoid
	if (@packageWeight=@updateweight)
		begin
			set @absoluteWeight = 1
		end
	else
		begin
			set @absoluteWeight = 0
		end
	insert into MaterialUpdateInfo(ParentId,batchnum,AbsoluteWeight,UpdateState,UpdateWeight,UpdateDateTime,UpdateUserName)
	values(@parenid,@batchnum,@absoluteWeight,@updatestate,@updateweight,@updatedatetime,@updateusername)
END
go

