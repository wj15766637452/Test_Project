-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[sheet_state_batch]
   ON  dbo.BurdenSheet 
   AFTER UPDATE
AS
	if UPDATE(state) 
BEGIN
	declare @batch nvarchar(50)
	declare @state int
	declare @count int
	declare @username nvarchar(50)
	select @batch=Batch,@state=State from inserted

	--判断这个配料编号是不是没有重复
	select @count = count(distinct State) from BurdenSheet where Batch = @batch and State not in (2,3)
	if (@count = 0)
	begin
		select top 1 @username = BurdenUserName from BurdenProcess where Batch = @batch order by BurdenDateTime desc	
		if (@state = 2)
		begin
			UPDATE Batch set State = 2,UpdateUserName=@username,UpdateDateTime=GETDATE() where Batch = @batch
		end
		if (@state = 3)
		begin
			select @count = count(distinct State) from BurdenSheet where Batch = @batch and State !=3
			if (@count =0)
			begin
				UPDATE Batch set State = 3,UpdateUserName=@username,UpdateDateTime=GETDATE() where Batch = @batch
			end
		end
	end
END
go

