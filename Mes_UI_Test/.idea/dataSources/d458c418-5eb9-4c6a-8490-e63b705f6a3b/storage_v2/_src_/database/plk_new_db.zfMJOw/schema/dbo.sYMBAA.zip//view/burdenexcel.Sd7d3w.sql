CREATE VIEW [dbo].[burdenExcel]
AS
SELECT   d.FomulaCode, a.batch, c.Iquantity, c.StartDateTime, c.CompleteDateTime, DATEDIFF(MINUTE, c.StartDateTime, 
                c.CompleteDateTime) AS ContinuedMinute, b.MaterialItem, a.MaterialCode, a.MaterialBatch, e.MaterialName, 
                b.Proportion, b.Iquantity_gw, a.Before_Store, a.Actual_nw , (cast(a.Before_Store  as float )*100 - cast(a.Actual_nw  as float )* 100)  /100 AS GobackWeight, a.Actual_Diff, 
                f.PackageWeight, a.BurdenUserName, a.BurdenDateTime, a.CheckUserName, a.CheckDateTime, a.FeedDateTime, 
                a.FeedUserName
FROM      dbo.BurdenProcess AS a INNER JOIN
                dbo.BurdenSheet AS b ON a.BurdenCode = b.BurdenCode INNER JOIN
                dbo.Batch AS c ON a.batch = c.Batch INNER JOIN
                dbo.Wocode AS d ON c.Wocode = d.Wocode INNER JOIN
                dbo.Material AS e ON a.MaterialCode = e.MaterialCode INNER JOIN
                dbo.MaterialInfo AS f ON a.MaterialCode = f.MaterialCode
go

